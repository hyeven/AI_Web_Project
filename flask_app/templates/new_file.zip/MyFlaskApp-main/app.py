from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')              # main 경로
def home():
    return render_template('main.html')

@app.route('/payloadInput')  # /payloadInput 경로 추가
def payload_input():
    return render_template('payloadInput.html')  # payloadInput.html 렌더링

@app.route('/payloadOutput')  # /payloadOutput 경로 추가
def payload_output():
    return render_template('payloadOutput.html')  # payloadOutput.html 렌더링

@app.route('/payloadResult')  # /payloadResult 경로 추가
def payload_result():
    return render_template('payloadResult.html')  # payloadResult.html 렌더링

@app.route('/register')  # /register 경로 추가
def register():
    return render_template('register.html')  # register.html 렌더링

@app.route('/forgotPassword')  # /register 경로 추가
def forgot_password():
    return render_template('forgotPassword.html')  # register.html 렌더링

if __name__ == '__main__':
    app.run(debug=True)
